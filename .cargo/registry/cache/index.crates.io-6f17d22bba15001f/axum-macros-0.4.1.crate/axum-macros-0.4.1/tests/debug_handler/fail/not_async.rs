use axum_macros::debug_handler;

#[debug_handler]
fn handler() {}

fn main() {}
